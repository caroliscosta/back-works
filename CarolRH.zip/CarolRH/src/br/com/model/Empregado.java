package br.com.model;

public class Empregado {
	private long cpf;
	private String nome;
	private String cargo;
	
	public Empregado () {
		this.cpf = cpf;
		this.nome = nome;
		this.cargo = cargo;
	}
	
	public long getCpf() {
		return cpf;
	}
	
	public String getNome() {
		return nome;
	}
	
	public String getCargo() {
		return cargo;
	}
	
	public void setCpf(long cpf) {
		this.cpf = cpf;
	}
	
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public void setCargo(String cargo) {
		this.cargo = cargo;
	}
}
