package br.com.model;

public class Departamento {
	private int numero;
	private String nome; 
	
	public Departamento() {
		this.numero = numero;
		this.nome = nome;
	}
	
	public int getNumero() {
		return numero;
	}
	
	public String nome() {
		return nome;
	}
	
	public void setNumero(int numero) {
		this.numero = numero;
	}
	
	public void setNome(String nome) {
		this.nome = nome;
	}
}