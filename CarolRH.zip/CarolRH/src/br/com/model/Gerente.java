package br.com.model;

public class Gerente extends Empregado {
	
	public Gerente() {
		super();
		
	}
	

}