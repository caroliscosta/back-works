package br.com.view;
import br.com.controller.DepartamentoBO;
import br.com.controller.EmpregadoBO;

import java.util.Scanner;

public class CadastroEmpregados {
	
	
		public static void main(String[] args) {
		Scanner entrada = new Scanner(System.in);
		EmpregadoBO empregado = new EmpregadoBO();
		DepartamentoBO departamento = new DepartamentoBO();
		
		
		boolean menu = true;
		String nome, cargo;
		long cpf;
		int numero;
		
		System.out.println("========================");
		System.out.println("====FIS software ERP====");
		System.out.println("========================");
				
		while(menu){
		System.out.println("Olá! O que você deseja fazer?");
		System.out.println("1-Listar cadastros");
		System.out.println("2-Efetuar novo cadastro");
		System.out.println("99-Sair");
		int opcao = new Scanner(System.in).nextInt();	
			
		switch(opcao) {
		case 1:
			System.out.println("1-Listar empregados");
			System.out.println("2-Listar departamentos");
			int opcaolist = new Scanner(System.in).nextInt();
			if (opcaolist == 1) {
				empregado.getAll();
				System.exit(0);
			}
				else if (opcaolist == 2){
					departamento.getAll();
					System.exit(0);
				}
				
				else {
					System.out.println("Opção inválida!");
				}
					
				break;
		
		
		case 2:
		while(menu) {
			System.out.println("O que você deseja cadastrar?");
			System.out.println("1-Departamento");
			System.out.println("2-Funcionário");
			System.out.println("3-Gerentes");
			System.out.println("99-Sair");
			int opcaocad = new Scanner(System.in).nextInt();		
						
			switch(opcaocad) {
				case 1: 
					departamento.cadastrarDepartamento();
					System.out.println("Confirma a inserção dos dados? 1-Sim 2-Não");
					int save = new Scanner(System.in).nextInt();
					if(save == 1) {
						departamento.salvarDepartamento();
					}
					else {
						menu = false;
						System.exit(0);
					}
					break;
				case 2: 
					empregado.cadastrarFuncionario();
					System.out.println("Confirma a inserção dos dados? 1-Sim 2-Não");
					int save1 = new Scanner(System.in).nextInt();
					if(save1 == 1) {
						empregado.salvarEmpregado();
					}
					else{
						menu = false;
						System.exit(0);
					}
					break;
				case 3: 
					empregado.cadastrarFuncionario();
					System.out.println("Confirma a inserção dos dados? 1-Sim 2-Não");
					int save2 = new Scanner(System.in).nextInt();
					if(save2 == 1) {
						empregado.salvarEmpregado();
					}
					else {
						menu = false;
						System.exit(0);
					}
					break;
				case 99:
					System.out.println("========================");
					System.out.println("====FIS software ERP====");
					System.out.println("========================");
					menu = false;
					System.exit(0);
					break;
				default:
					System.out.print("Opção inválida!");
					break;		
			}
		}
		case 99:
			System.out.println("========================");
			System.out.println("====FIS software ERP====");
			System.out.println("========================");
			menu = false;
			System.exit(0);
			break;	
		default:
			System.out.print("Opção inválida!");
			break;	
			
		}


		}
		

		}
		
}
		

