package br.com.controller;

import java.util.ArrayList;
import java.util.Scanner;
import br.com.model.Empregado;

public class EmpregadoBO extends Empregado{
	
	String nome;
	long cpf;
	int numero;

	ArrayList<Empregado> empregado =  new ArrayList<>(); 

	
	public EmpregadoBO() {
		super();
	}
		
	Scanner entrada = new Scanner(System.in);
	

	public void cadastrarFuncionario() {
	System.out.println("Digite o nome do Funcionário: ");
	String nome = entrada.nextLine();
	System.out.println("Digite o CPF do Funcionário: ");
	long cpf = entrada.nextLong();
	
	
	}
	
	public void salvarEmpregado() {
		boolean verif = false;
		
		for (int i = 0; i < empregado.size(); i++) {
			
		if (empregado.get(i).getCpf() != -1){
			System.out.println("Empregado já cadastrado!");
			verif = true;
		}
        
		
		else if(!verif) {
			empregado.add(new EmpregadoBO());
			System.out.println("Funcionario cadastrado com sucesso!");
			}
		}
		
	}

	
	public void getAll() {
		System.out.println("Lista de Empregados:");
				
		for (int i = 0; i < empregado.size(); i++) {
			System.out.println(empregado.get(i).toString());
		}
	}
}