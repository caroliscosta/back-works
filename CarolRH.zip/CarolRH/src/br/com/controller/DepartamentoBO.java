package br.com.controller;

import java.util.ArrayList;
import java.util.Scanner;
import br.com.model.*;

import br.com.model.Departamento;

public class DepartamentoBO extends Departamento {
	
	String nome;
	int numero;
	ArrayList<Departamento> departamento = new ArrayList<>();
	
	Scanner entrada = new Scanner(System.in);
	
	
	public DepartamentoBO() {
		super();
	}
	

	public void cadastrarDepartamento() {
		System.out.println("Digite o nome do Departamento: ");
		String nome = entrada.nextLine();
		System.out.println("Digite o número do Departamento: ");
		int numero = entrada.nextInt();
		
	}
	
	
	public void salvarDepartamento() {
		departamento.add(new DepartamentoBO());
		System.out.println("Departamento cadastrado com sucesso!");
	}
	

	public void getAll() {
		System.out.println("Lista de Departamentos:");
				
		for (int i = 0; i < departamento.size(); i++) {
			System.out.println(departamento.get(i));
		}
	}
}
